<?PHP
// config file 
 include("config.php"); ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset='utf-8'>
  <meta http-equiv="X-UA-Compatible" content="chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" media="screen" href="assets/jquery-ui.min.css">
  <link rel="stylesheet" type="text/css" media="screen" href="fancybox/jquery.fancybox.css">
  <link rel="stylesheet" type="text/css" media="screen" href="assets/style.css">
  <link rel="stylesheet" type="text/css" media="screen" href="assets/load-data.css">
  <!-- Only include on form edit page -->
  <link rel="stylesheet" type="text/css" media="screen" href="assets/form-builder.min.css">
  <!-- Only include on form render page -->
  <link rel="stylesheet" type="text/css" media="screen" href="assets/form-render.min.css">
  <title>FormBuilder | Wire delta</title>
</head>

<body>
  <div class="demo-wrap">
    <div id="header_wrap" class="outer">
        </div>
    <!-- MAIN CONTENT -->
		<div id="main_content_wrap" class="outer">
      <section id="main_content" class="inner">
        <div class="build-form">
          <h2><strong>Build The Form</strong></h2>
          <form id="rendered-forfm"  >
            <textarea name="form-builder-template" id="form-builder-template" cols="30" rows="10"></textarea>
          </form>
          <br style="clear:both">
		          <div class="render-form">
          <h2><strong>Render The Form</strong></h2>
		  <div id="form-html">
			  <form id="rendered-form" class="form-style-1" action="javascript:test();" >
				<p class="cta">Add some fields to the formBuilder above and render them here.</p>
			  </form>
			  
		  </div>
          <div class="render-description">
            <button id="render-form-button" class="btn btn-primary">Render the form</button>
          </div>
		  	
			<br style="clear:both">
			<?PHP   $counter = mysql_query("SELECT COUNT(*) AS id FROM html_data");
					$num = mysql_fetch_array($counter);
					$count = $num["id"];
					//echo("$count"); 
					if($count!=0){ ?>
			<p align="center"><h3>Stored Templates(Kindly refresh once you rendered the form)</h3></p>
				<div align="center" class="">
				<?PHP $select= mysql_query("SELECT * FROM html_data");
				
					while($result=mysql_fetch_array($select)){
						$id =  $result['id'];	
						echo '<a class="template fancybox fancybox.iframe" href="'.$_SERVER['REQUEST_URI'].'/load-data.php?id='.$id.'"><b>Template '.$id.'</b></a>
						<div id="" class="fancybox">
							
							  <input type="hidden" value="'.$result['id'].'">
						</div>';
					}
				?>
				</div>
				<?PHP } else {echo '<a href="'.$_SERVER['REQUEST_URI'].'">Stored Templates </a>'; } ?>
			</div>
        </div>
        <br style="clear:both">
      </section>
    </div>
    <!-- FOOTER  -->
  </div>
  <script src="assets/jquery.min.js"></script>
  <script src="assets/jquery-ui.min.js"></script>
  <script src="fancybox/jquery.fancybox.js"></script>
  <!-- Only include on form edit page -->
  <script src="assets/form-builder.min.js"></script>
  <!-- Only include on form render page -->
  <script src="assets/form-render.min.js"></script>
  <script>
  jQuery(document).ready(function($) {

  $('.fancybox').fancybox({
  
  });
    'use strict';
    var template = document.getElementById('form-builder-template'),
      formContainer = document.getElementById('rendered-form'),
      renderBtn = document.getElementById('render-form-button');
    $(template).formBuilder();

    $(renderBtn).click(function(e) {
	
      e.preventDefault();
	 
      $(template).formRender({
        container: $(formContainer)
      });
	  
	  var val=$("#form-html").html();
	  $.ajax({ url: 'ajax.php',
		 data: {'data_value' : val},
		 type: 'post',
		 dataType:'json',
		 success: function(output) {
					  //alert(output);
				  },
		  error: function(request, status, error){
			//alert("Error: Could not delete");
		  }
	});
	  $("#rendered-form").append("<input type='submit' value='submit' name='submit' />");
	  
    });
	 $(".frmb-control li:nth-child(4)").hide();
		
  });
  </script>
 
 
  
</body>

</html>
