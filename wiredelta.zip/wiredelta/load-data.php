<link rel="stylesheet" type="text/css" media="screen" href="assets/load-data.css">
<?PHP include("config.php");
$sql = mysql_query("SELECT * FROM html_data where id=".$_REQUEST['id']);
$result=mysql_fetch_array($sql);
echo "<!DOCTYPE html>
<html>
		<body>
		".$result['template_data']."
		<input type='submit' class='check' value='Submit'>
		</body>
	</html>"
?>
<script src="assets/jquery.min.js"></script>
  <script src="assets/jquery-ui.min.js"></script>
<script>
$(".check").click(function(){
	$('form#rendered-form').find('input').each(function(){

       if($(this).prop('required')&& $(this).val()=='')
        {
           $(this).css("border-color", "red");
        }else{
		 $(this).css("border-color", "");
		}
    

	});
});
</script>